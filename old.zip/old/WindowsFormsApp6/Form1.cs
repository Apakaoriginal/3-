﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApp6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_123DataSet.Группы". При необходимости она может быть перемещена или удалена.
            this.группыTableAdapter.Fill(this._123DataSet.Группы);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_123DataSet._1". При необходимости она может быть перемещена или удалена.
            this._1TableAdapter.Fill(this._123DataSet._1);
        }

        private void toolStripComboBox1_Click(object sender, EventArgs e)
        {
            // Обработчик события для toolStripComboBox1
        }
        private void button1_Click_1(object sender, EventArgs e)
        {
            Form form2 = new Form2();
            form2.Show();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Form form3 = new Form3();
            form3.Show();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            Form form4 = new Form4();
            form4.Show();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            Form form5 = new Form5();
            form5.Show();
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            Form form6 = new Form6();
            form6.Show();
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            Form form7 = new Form7();
            form7.Show();
        }
    }
}