﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class regis22 : Form
    {
        public regis22()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox2.Text))
            {
                MessageBox.Show("Заполните все поля", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            using (var connection = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=user_pass.accdb;"))
            {
                try
                {
                    connection.Open();

                    // Проверяем, существует ли такой логин
                    using (OleDbCommand cmd = new OleDbCommand("SELECT * FROM Users WHERE Login = ?", connection))
                    {
                        cmd.Parameters.AddWithValue("@Login", textBox1.Text); // Изменил на именованные параметры - более читабельно
                        using (var reader = cmd.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                MessageBox.Show("Такой аккаунт уже существует!", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                        }
                    }

                    // Записываем нового пользователя  (Используем именованные параметры)


                    using (OleDbCommand cmd = new OleDbCommand("INSERT INTO Users ([Login], [Password]) VALUES (?, ?)", connection))
                    {
                        // Добавляем первый параметр (Login)
                        cmd.Parameters.Add("Login", OleDbType.VarChar).Value = textBox1.Text;

                        // Добавляем второй параметр (Password)
                        cmd.Parameters.Add("Password", OleDbType.VarChar).Value = textBox2.Text;

                        // Выполняем команду
                        cmd.ExecuteNonQuery();
                    }



                    MessageBox.Show("Ваш аккаунт успешно зарегистрирован", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
                catch (OleDbException ex)
                {
                    MessageBox.Show($"Ошибка при работе с базой данных: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Произошла непредвиденная ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            auth auth = new auth();
            auth.Show();
            this.Hide();
        }
    }
}
