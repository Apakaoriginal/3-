﻿using System;
using System.Data;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void врачиBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            ValidateAndSave();
        }

        private void ValidateAndSave()
        {
            try
            {
                this.Validate();
                this.врачиBindingSource.EndEdit();
                this.tableAdapterManager.UpdateAll(this.microsoft_Access_База_данныхDataSet2);
                ShowSuccessMessage("Данные сохранены успешно!");
            }
            catch (DBConcurrencyException dbEx)
            {
                ShowErrorMessage($"Ошибка конкурентного доступа: {dbEx.Message}");
            }
            catch (DataException dataEx)
            {
                ShowErrorMessage($"Ошибка данных: {dataEx.Message}");
            }
            catch (Exception ex)
            {
                ShowErrorMessage($"Ошибка при сохранении данных: {ex.Message}");
            }
        }

        private void ShowSuccessMessage(string message)
        {
            MessageBox.Show(message, "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void ShowErrorMessage(string message)
        {
            MessageBox.Show(message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Логика обработки события
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ShowFormAndHideCurrent(new Zapros2());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ShowFormAndHideCurrent(new Zapros3());
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ShowFormAndHideCurrent(new Zapros4());
        }

        private void ShowFormAndHideCurrent(Form form)
        {
            form.Show();
            this.Hide();
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {
            // Логика обработки события
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.врачиTableAdapter.Fill(this.microsoft_Access_База_данныхDataSet2.Врачи);
            this.пациентыTableAdapter.Fill(this.microsoft_Access_База_данныхDataSet2.Пациенты);
            this.диагнозыTableAdapter.Fill(this.microsoft_Access_База_данныхDataSet2.Диагнозы);
        }

        private void врачиDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Логика обработки события
        }

        private void врачиDataGridView_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            // Логика обработки события
        }

        private void button4_Click(object sender, EventArgs e)
        {
            auth auth = new auth();
            auth.Show();
            this.Hide();
        }

        

        private void buttonSave_Click(object sender, EventArgs e)
        {
            SaveChanges(пациентыBindingSource);
        }

        private void SaveVrach_Click(object sender, EventArgs e)
        {
            SaveChanges(врачиBindingSource);
        }

        

        private void SaveDiag_Click(object sender, EventArgs e)
        {
            SaveChanges(диагнозыBindingSource);
        }

        private void SaveChanges(BindingSource bindingSource)
        {
            bindingSource.EndEdit();
            ValidateAndSave();
        }

        private void DeleteSelectedRow(DataGridView dataGridView, BindingSource bindingSource, string tableName)
        {
            if (dataGridView.SelectedRows.Count > 0)
            {
                if (MessageBox.Show($"Вы уверены, что хотите удалить выбранную строку из таблицы '{tableName}'?", "Подтверждение удаления", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    try
                    {
                        bindingSource.RemoveCurrent();
                        ValidateAndSave();
                        ShowSuccessMessage("Строка успешно удалена.");
                    }
                    catch (Exception ex)
                    {
                        ShowErrorMessage($"Ошибка при удалении строки: {ex.Message}");
                    }
                }
            }
            else
            {
                ShowErrorMessage("Выберите строку для удаления.");
            }
        }

        private void BazaVrach_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            ShowFormAndHideCurrent(new vrach());
        }

        private void BazaDiag_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            ShowFormAndHideCurrent(new diag());
        }

        private void BazaPac_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            ShowFormAndHideCurrent(new pac());
        }

        private void button5_Click(object sender, EventArgs e)
        {
            ShowFormAndHideCurrent(new Form2());
        }
    }
}