﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.microsoft_Access_База_данныхDataSet2 = new WindowsFormsApp1.Microsoft_Access_База_данныхDataSet2();
            this.врачиBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.врачиTableAdapter = new WindowsFormsApp1.Microsoft_Access_База_данныхDataSet2TableAdapters.ВрачиTableAdapter();
            this.tableAdapterManager = new WindowsFormsApp1.Microsoft_Access_База_данныхDataSet2TableAdapters.TableAdapterManager();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.microsoftAccessБазаданныхDataSet2BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.врачиBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.диагнозыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.пациентыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.диагнозыTableAdapter = new WindowsFormsApp1.Microsoft_Access_База_данныхDataSet2TableAdapters.ДиагнозыTableAdapter();
            this.пациентыTableAdapter = new WindowsFormsApp1.Microsoft_Access_База_данныхDataSet2TableAdapters.ПациентыTableAdapter();
            this.button4 = new System.Windows.Forms.Button();
            this.BazaVrach = new System.Windows.Forms.LinkLabel();
            this.BazaDiag = new System.Windows.Forms.LinkLabel();
            this.BazaPac = new System.Windows.Forms.LinkLabel();
            this.button5 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.microsoft_Access_База_данныхDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.врачиBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.microsoftAccessБазаданныхDataSet2BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.врачиBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.диагнозыBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.пациентыBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // microsoft_Access_База_данныхDataSet2
            // 
            this.microsoft_Access_База_данныхDataSet2.DataSetName = "Microsoft_Access_База_данныхDataSet2";
            this.microsoft_Access_База_данныхDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // врачиBindingSource
            // 
            this.врачиBindingSource.DataMember = "Врачи";
            this.врачиBindingSource.DataSource = this.microsoft_Access_База_данныхDataSet2;
            // 
            // врачиTableAdapter
            // 
            this.врачиTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.UpdateOrder = WindowsFormsApp1.Microsoft_Access_База_данныхDataSet2TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.ВрачиTableAdapter = this.врачиTableAdapter;
            this.tableAdapterManager.ДиагнозыTableAdapter = null;
            this.tableAdapterManager.ПациентыTableAdapter = null;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.Location = new System.Drawing.Point(104, 63);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(99, 31);
            this.button1.TabIndex = 2;
            this.button1.Text = "Запрос 2";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button2.Location = new System.Drawing.Point(209, 63);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(99, 31);
            this.button2.TabIndex = 3;
            this.button2.Text = "Запрос 3";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button3.Location = new System.Drawing.Point(314, 63);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(99, 31);
            this.button3.TabIndex = 4;
            this.button3.Text = "Запрос 4";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // microsoftAccessБазаданныхDataSet2BindingSource
            // 
            this.microsoftAccessБазаданныхDataSet2BindingSource.DataSource = this.microsoft_Access_База_данныхDataSet2;
            this.microsoftAccessБазаданныхDataSet2BindingSource.Position = 0;
            // 
            // врачиBindingSource1
            // 
            this.врачиBindingSource1.DataMember = "Врачи";
            this.врачиBindingSource1.DataSource = this.microsoftAccessБазаданныхDataSet2BindingSource;
            // 
            // диагнозыBindingSource
            // 
            this.диагнозыBindingSource.DataMember = "Диагнозы";
            this.диагнозыBindingSource.DataSource = this.microsoft_Access_База_данныхDataSet2;
            // 
            // пациентыBindingSource
            // 
            this.пациентыBindingSource.DataMember = "Пациенты";
            this.пациентыBindingSource.DataSource = this.microsoft_Access_База_данныхDataSet2;
            // 
            // диагнозыTableAdapter
            // 
            this.диагнозыTableAdapter.ClearBeforeFill = true;
            // 
            // пациентыTableAdapter
            // 
            this.пациентыTableAdapter.ClearBeforeFill = true;
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button4.Location = new System.Drawing.Point(419, 61);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(233, 33);
            this.button4.TabIndex = 7;
            this.button4.Text = "Выйти из учетной записи";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // BazaVrach
            // 
            this.BazaVrach.AutoSize = true;
            this.BazaVrach.Font = new System.Drawing.Font("Comic Sans MS", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BazaVrach.LinkColor = System.Drawing.Color.Black;
            this.BazaVrach.Location = new System.Drawing.Point(14, 6);
            this.BazaVrach.Name = "BazaVrach";
            this.BazaVrach.Size = new System.Drawing.Size(265, 45);
            this.BazaVrach.TabIndex = 8;
            this.BazaVrach.TabStop = true;
            this.BazaVrach.Text = "Преподаватели";
            this.BazaVrach.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.BazaVrach_LinkClicked);
            // 
            // BazaDiag
            // 
            this.BazaDiag.AutoSize = true;
            this.BazaDiag.Font = new System.Drawing.Font("Comic Sans MS", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BazaDiag.LinkColor = System.Drawing.Color.Black;
            this.BazaDiag.Location = new System.Drawing.Point(285, 6);
            this.BazaDiag.Name = "BazaDiag";
            this.BazaDiag.Size = new System.Drawing.Size(141, 45);
            this.BazaDiag.TabIndex = 9;
            this.BazaDiag.TabStop = true;
            this.BazaDiag.Text = "Группы";
            this.BazaDiag.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.BazaDiag_LinkClicked);
            // 
            // BazaPac
            // 
            this.BazaPac.AutoSize = true;
            this.BazaPac.Font = new System.Drawing.Font("Comic Sans MS", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BazaPac.LinkColor = System.Drawing.Color.Black;
            this.BazaPac.Location = new System.Drawing.Point(432, 6);
            this.BazaPac.Name = "BazaPac";
            this.BazaPac.Size = new System.Drawing.Size(226, 45);
            this.BazaPac.TabIndex = 10;
            this.BazaPac.TabStop = true;
            this.BazaPac.Text = "Дисциплины";
            this.BazaPac.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.BazaPac_LinkClicked);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(12, 63);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(87, 31);
            this.button5.TabIndex = 11;
            this.button5.Text = "Запрос 1";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.ClientSize = new System.Drawing.Size(664, 111);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.BazaPac);
            this.Controls.Add(this.BazaDiag);
            this.Controls.Add(this.BazaVrach);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.microsoft_Access_База_данныхDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.врачиBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.microsoftAccessБазаданныхDataSet2BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.врачиBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.диагнозыBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.пациентыBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Microsoft_Access_База_данныхDataSet2 microsoft_Access_База_данныхDataSet2;
        private System.Windows.Forms.BindingSource врачиBindingSource;
        private Microsoft_Access_База_данныхDataSet2TableAdapters.ВрачиTableAdapter врачиTableAdapter;
        private Microsoft_Access_База_данныхDataSet2TableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.BindingSource microsoftAccessБазаданныхDataSet2BindingSource;
        private System.Windows.Forms.BindingSource врачиBindingSource1;
        private System.Windows.Forms.BindingSource диагнозыBindingSource;
        private Microsoft_Access_База_данныхDataSet2TableAdapters.ДиагнозыTableAdapter диагнозыTableAdapter;
        private System.Windows.Forms.BindingSource пациентыBindingSource;
        private Microsoft_Access_База_данныхDataSet2TableAdapters.ПациентыTableAdapter пациентыTableAdapter;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.LinkLabel BazaVrach;
        private System.Windows.Forms.LinkLabel BazaDiag;
        private System.Windows.Forms.LinkLabel BazaPac;
        private System.Windows.Forms.Button button5;
    }
}

