﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Zapros4 : Form
    {
        public Zapros4()
        {
            InitializeComponent();
        }

        private void Zapros4_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_123DataSet._4". При необходимости она может быть перемещена или удалена.
            this._4TableAdapter.Fill(this._123DataSet._4);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "microsoft_Access_База_данныхDataSet2.Запрос_4". При необходимости она может быть перемещена или удалена.
            this.запрос_4TableAdapter.Fill(this.microsoft_Access_База_данныхDataSet2.Запрос_4);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 Form1 = new Form1();
            Form1.Show();
            this.Hide();
        }
    }
}
