﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class diag : Form
    {
        public diag()
        {
            InitializeComponent();
        }

        private void диагнозыBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.диагнозыBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.microsoft_Access_База_данныхDataSet2);

        }

        private void diag_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_123DataSet.Группы". При необходимости она может быть перемещена или удалена.
            this.группыTableAdapter.Fill(this._123DataSet.Группы);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_123DataSet._1". При необходимости она может быть перемещена или удалена.
            this._1TableAdapter.Fill(this._123DataSet._1);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "microsoft_Access_База_данныхDataSet2.Диагнозы". При необходимости она может быть перемещена или удалена.
            this.диагнозыTableAdapter.Fill(this.microsoft_Access_База_данныхDataSet2.Диагнозы);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 Form1 = new Form1();
            Form1.Show();
            this.Hide();
        }
    }
}
